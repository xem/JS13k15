/** Initializations **/

// Debug
_ = function(a){ console.log(a) }

// Names of places, capitols, us capitols, countries, us states, in one string (0: category separator, 1: difficulty separator)
g = "Cape canaveralChrist the redeemerThe great chinese wallThe great sphinxThe eiffel towerTower of pisaMount everestSagrada familiaBig benThe statue of libertyForbidden cityThe pyramids of gizaThe palace of versaillesAcropolisTrevi fountainKremlinLoch nessAtomiumLascaux cavesMont st. michelPiazza san marcoThe grand canyonMillau bridgeRock of gibraltarThe empire state buildingHollywood signTimes squareLouvre museumWhite houseFlorence cathedralLas vegasMadrid palaceCentral parkSistine chapelPiazza del campo1Machu picchuThe burj al arab hotelSt. peter's cathedralKilimanjaroCapitol hillLuxor templeGolden gate bridgeBurj khalifaAlcatrazEphesusManneken pisMount eden craterNorth capeSt. basil's cathedralVictoria fallsThe great buddhaLotus templeThe colosseumAbu simbelPetronas twin towersYellowstoneNiagara fallsThe taj mahalMount fujiMeccaAuschwitzStonehengeMount rushmorePentagonCape of good hopeOpera houseParc guellPompeiiDead sea1WaterlooEaster islandEvergladesCloud gateRialto bridgeWillis towerLittle mermaidTower bridgeThe blue mosqueNevado mismiTable mountainMinaret of jamAngkor watFaisal mosqueNeuschwanstein castleGolden temple of amritsarAl aqsa mosqueTemple of besakihChichen itzaBran castleHagia sophiaUluruBrandenburg gateBlue domed churchTaal lakeCheyenne mountainKiyomizu-deraPetraTombouctouKultury i nauki palace0AlgiersBuenos airesCanberraViennaBrusselsBrasiliaSofiaOttawaSantiagoBeijingZagrebHavanaPragueCopenhagenQuitoCairoTallinnHelsinkiParisBerlinAthensBudapestReykjavikNew delhiJakartaTehranBaghdadDublinJerusalemRomeKingstonTokyoBeirutVilniusLuxembourgSkopjeAntananarivoMexico cityMonacoRabatKathmanduAmsterdamWellingtonPyongyangOsloRamallahAsunciónLimaManilaWarsawLisbonBucharestDohaMoscowRiyadhSingaporeBratislavaLjubljanaPretoriaSeoulMadridStockholmBernTaipeiTunisAnkaraKyivMontevideoAbu dhabiLondonWashington d.c.CaracasVatican cityHanoiGeorgetownTripoli1KabulAndorra la vellaTiranaMinskSarajevoOuagadougouYaoundéBanguiBrazzavilleKinshasaYamoussoukroSan joseBogotáLa pazPraiaNicosiaPorto-novoPhnom penhRoseauSanto domingoMalaboGuatemala cityPort-au-princeTegucigalpaAmmanAstanaPristinaKuwait cityVientianeNairobiKuala lumpurBamakoVallettaChisinauIslamabadPanama citySan marinoDakarBelgradeVictoriaMogadishuSri jayawardenepura kotteKhartoumDodomaBangkokSana'aHarare1Saint john'sYerevanBakuLuandaNassauManamaDhakaBridgetownBelmopanThimphuGaboroneBandar seri begawanBujumburaN'djamenaMoroniDjiboutiSan salvadorAsmaraAddis ababaSuvaLibrevilleBanjulTbilisiAccraSt. george'sConakryBissauSouth tarawaBishkekRigaMaseruMonroviaVaduzLilongweMaleMajuroNouakchottPort louisPalikirUlaanbaatarPodgoricaMaputoNaypyidawWindhoekYaren districtManaguaNiameyAbujaMuscatNgerulmudPort moresbyKigaliBasseterreCastriesKingstownApiaSão toméFreetownHoniaraJubaParamariboMbabaneDamascusDushanbeDiliLoméNuku'alofaPort of spainAshgabatFunafutiKampalaTashkentPort vilaLusakaZZZZ0HonoluluJuneauOlympiaCarson citySanta feAlbanyTallahasseeSpringfieldColumbusProvidenceColumbiaAustinSalt lake cityRichmondCharlestonHarrisburgBostonRaleighMontgomerySacramentoDenverAtlantaLansing1BismarckHelenaLincolnPhoenixLittle rockConcordTrentonHartfordDoverOklahoma cityBoiseSalemIndianapolisDes moinesTopekaPierreFrankfortNashvilleBaton rougeAugustaAnnapolisMontpelierSt. paulJacksonMadisonJefferson cityCheyenne0AlgeriaArgentinaAustraliaAustriaBelgiumBrazilBulgariaCanadaChileChinaCroatiaCubaCzech republicDenmarkEcuadorEgyptEstoniaFinlandFranceGermanyGreeceHungaryIcelandIndiaIndonesiaIranIraqIrelandIsraelItalyJamaicaJapanLebanonLithuaniaLuxembourgMacedoniaMadagascarMexicoMonacoMoroccoNepalNetherlandsNew zealandNorth koreaNorwayPalestineParaguayPeruPhilippinesPolandPortugalRomaniaQatarRussiaSaudi arabiaSingaporeSlovakiaSloveniaSouth africaSouth koreaSpainSwedenSwitzerlandTaiwanTunisiaTurkeyUkraineUruguayUnited arab emiratesUnited kingdomU.s.a.VenezuelaVatican cityVietnamGuyanaLibya1AfghanistanAndorraAlbaniaBelarusBosnia and herzegovina Burkina fasoCameroonCentral african republicRepublic of the congo Democratic republic of the congo Cote d'ivoireCosta ricaColombiaBoliviaCabo verdeCyprusBeninCambodiaDominicaDominican republicEquatorial guineaGuatemalaHaitiHondurasJordanKazakhstanKosovoKuwaitLaosKenyaMalaysiaMaliMaltaMoldovaPakistanPanamaSan marinoSenegalSerbiaSeychellesSomaliaSri lankaSudanTanzaniaThailandYemenZimbabwe1Antigua and barbudaArmeniaAzerbaijanAngolaBahamasBahrainBangladeshBarbadosBelizeBhutanBotswanaBruneiBurundiChadComorosDjiboutiEl salvadorEritreaEthiopiaFijiGabonGambiaGeorgiaGhanaGrenadaGuineaGuinea-bissauKiribatiKyrgyzstanLatviaLesothoLiberiaLiechtensteinMalawiMaldivesMarshall islandsMauritaniaMauritiusMicronesiaMongoliaMontenegroMozambiqueMyanmarNamibiaNauruNicaraguaNigerNigeriaOmanPalauPapua new guineaRwandaSaint kitts and nevisSaint luciaSaint vincent and the grenadinesSamoaSao tome and principeSierra leoneSolomon islandsSouth sudanSurinameSwazilandSyriaTajikistanTimor-lesteTogoTongaTrinidad and tobagoTurkmenistanTuvaluUgandaUzbekistanVanuatuZambia1ZZZZ0HawaiiAlaskaWashingtonNevadaNew mexicoNew yorkFloridaIllinoisOhioRhode islandSouth carolinaTexasUtahVirginiaWest virginiaPennsylvaniaMassachusettsNorth carolinaAlabamaCaliforniaColoradoGeorgiaMichigan1North dakotaMontanaNebraskaArizonaArkansasNew hampshireNew jerseyConnecticutDelawareOklahomaIdahoOregonIndianaIowaKansasSouth dakotaKentuckyTennesseeLouisianaMaineMarylandVermontMinnesotaMississippiWisconsinMissouriWyoming1ZZ".split(0);

// Context2d
h = $.getContext("2d");

// Math
m = Math;

// Game state
n = 0;

// Frame counter
o = 0;

// Puzzle score
p = 50000;

// Current level score
q = 30000;

// Total score
r = 0;

// Stars position and size
s = []; for(i = 0; i < 300; i++) s[i] = [m.random() * 1200, m.random() * 650, m.random() + .5];

// Text
t = function(x, y, text, size, color, align){
    size = size || 50;
    color = color || "#fff";
    align = align || "center";
    h.textAlign = align;
    h.fillStyle = color;
    h.font = size + "px Impact, Charcoal";
    h.strokeStyle = "#000";
    h.strokeText(text, x, y);
    h.fillText(text, x, y);
}

// Stars scroll offset
u = 0;

// Earth rotation offset
v = 0;

// Time out
z = 0;

// Current level / puzzle
A = 0;
B = 0;

// Click coords
X = 0;
Y = 0;

/** Gather & shuffle the data **/

// Load the game's data in AJAX, as an arrayBuffer, from the file called "1"
a = new XMLHttpRequest;
a.open("GET", 1);
a.responseType = 'arraybuffer';
a.send();
a.onload = function(){
    
    b = new Uint8Array(a.response);
    
    c = 0;
    
    // Reconstitute all the data
    // For each category
    for(i in g){
        g[i] = g[i].split(1);
        
        // For each difficulty
        for(j in g[i]){
            g[i][j] = g[i][j].split(/(?=[A-Z])/);
            
            // For each name
            for(k in g[i][j]){
                
                // Make an array with the name and the coordinates
                // 2 coordinates for places, capitols, us capitols
                if(i < 3){
                    g[i][j][k] = [g[i][j][k], [b[c], b[c+1]]];
                    c += 2;
                }
                
                // List of coordinates separated by 254 for countries and us states
                else{
                    g[i][j][k] = [g[i][j][k], []];
                    while(b[c]!= 254 && c < b.length){
                        g[i][j][k][1].push(b[c]);
                        c++;
                    }
                    c++;
                }
            }
        }
    }
    
    //_(g);
    
    // Hack for Algeria
    g[3][0][0][1] = [105,81,107,78,113,76,112,82,114,88,114,97,116,102,111,109,109,110,100,95,99,93,106,85,255,109,78];
    
    // Hack for Tallahassee
    g[2][0][6][1] = [207,218];
    
    // Hack for Bangui
    g[1][1][7][1] = [121,137];
    
    // Launch game
    w();
}

/** Game loop **/
w = function(){
    
    // Reset canvas
    $.width ^= 0;
    
    // Welcome screen
    if(n == 0){
        
        // Background
        h.fillRect(0,0,1200,650);
        
        // Stars
        u--;
        u %= 1200;

        for(i = 0; i < 300; i++){
          h.fillStyle = "#fff";
          h.beginPath();
          h.arc(a = s[i][0] + u, b = s[i][1], c = s[i][2] + m.random() * .2, 0, 7);
          h.arc(1200 + a, b, c, 0, 7);
          h.fill();
        }

        // Earth

        // Background
        h.beginPath();
        gradient = h.createLinearGradient(300,0,600,0);
        gradient.addColorStop(0,"#75D1FF");
        gradient.addColorStop(1,"#3591bF");
        h.fillStyle = gradient;
        h.arc(470, 260, 140, 0, 7);
        h.fill();
        
        // Rotation
        v++;
        v %= 220;
        
        // Draw countries
        h.strokeStyle = "#83864F";
        h.fillStyle = "#95D866";
        
        // Loop on difficulties
        for(i = 4; i--;){
            
            // Loop on countries
            for(j = 0; j < g[3][i].length; j++){
                
                // Current country (avoid the gap fillers)
                if((i == 3 && j == 3)) a = [];
                else a = g[3][i][j][1];
                
                // Loop on coordinates
                for(k = 0; k < a.length; k += 2){
                    
                    // Start new island
                    if(a[k] == 255){
                        k++;
                        h.closePath();
                        h.fill();
                        h.stroke();
                        h.beginPath();
                    }
                    
                    // Hack
                    if(a[k + 1] ==  255){
                        k += 2;
                        h.closePath();
                        h.fill();
                        h.stroke();
                        h.beginPath();
                    }

                    // Current point
                    x = (a[k] - v + 100) / 110;
                    y = (a[k+1] - 120) / 150;
                    
                    while(x > 1) x -= 2;
                    if(x > -1 && x < -.5) x = -0.5;
                    if(x > .5 && x < 1) x = 0.5;
                    
                    // Fix canada & russia
                    if(!k && g[3][i][j][0] != "Russia" && g[3][i][j][0] != "Canada"){
                        if(x < 0) b = -.5;
                        else b = .5;
                    }
                    
                    if(g[3][i][j][0] == "Russia"){
                        b = .5;
                        if(v > 50) b = -.5;
                        if(v > 160) b = .5;
                    }
                    
                    if(g[3][i][j][0] == "Canada"){
                        b = .5;
                        if(v > 160) b = -.5;
                        if(v < 50) b = -.5;
                    }
                    
                    if((x <= -.5 || x >= .5)) x = b;
                    
                    x = m.sin(x * m.PI) * m.cos(y * m.PI / 2);
                    y = m.sin(y * m.PI / 2);
                    x = x * 140 + 470;
                    y = y * 140 + 260;
                    
                    // Start country
                    if(k == 0){
                        h.beginPath();
                        h.moveTo(x, y);
                    }
                    
                    // Continue country
                    h.lineTo(x, y);
                }
                
                h.closePath();
                h.fill();
                h.stroke();
            }
        }

        // Text
        t(180, 375, "GE", 300);
        t(890, 375, "Quiz", 300);
        t(990, 405, "JS13kGames 2015", 30);
        t(600, 570, "START", 80);
    }
    
    // Level presentation screen
    else if(n == 1){
        
        // Background
        h.fillRect(0,0,1200,650);
        
        // Text
        t(600, 280, "Level " + (A + 1) + ":", 60);
        
        t(600,  360, [
        "Countries (easy)",
        "Capitols (easy)",
        "Famous places (easy)",
        "Countries (medium)",
        "Capitols (medium)",
        "U.S. states (medium)",
        "Famous places (medium)",
        "U.S. capitols (medium)",
        "World countries (hard)",
        "U.S. states (hard)",
        "Famous places (hard)",
        "U.S. capitols (hard)",
        "Capitols (hard)"
        ][A], 60);
        
        t(600, 450, "START", 30);
    }
    
    // Puzzle screen
    else if(n == 2 || n == 3){
        
        // Puzzles list
        C = [
            g[3][0],
            g[1][0],
            g[0][0],
            g[3][1],
            g[1][1],
            g[4][0],
            g[0][1],
            g[2][0],
            g[3][2],
            g[4][1],
            g[0][2],
            g[2][1],
            g[1][2]
        ][A];
            
        // Draw US map
        if(A == 5 || A == 7 || A == 9 || A == 11){
            f = 4
        }
        
        // Draw world map
        else{
            f = 3;
        }
            
        // Loop on difficulties
        for(i = g[f].length; i--;){
            
            // Loop on countries
            for(j = 0; j < g[f][i].length; j++){
                
                // Current country
                a = g[f][i][j][1];
                
                // Loop on coordinates
                for(k = 0; k < a.length; k += 2){
                    
                    // Start new island
                    if(a[k] == 255){
                        k++;
                        h.closePath();
                        h.fill();
                        h.stroke();
                        h.beginPath();
                    }
                    
                    // hack
                    if(a[k + 1] == 255){
                        k += 2;
                        h.closePath();
                        h.fill();
                        h.stroke();
                        h.beginPath();
                    }

                    // Current point
                    x = a[k] * (f == 4 ? 4.8 : 4.9);
                    y = a[k + 1] * (f == 4 ? 2.46 : 2.35) + (f == 4 ? 38 : 65);
                    if(B == 4 || B == 9){
                        x = 1200 - x;
                        y = 700 - y;
                    }
                    
                    // Start country
                    if(k == 0){
                        h.beginPath();
                        h.strokeStyle = B < 7 ? "#83864F" : "#000";
                        h.fillStyle = B < 7 ? "#95D866" : "#000";
                        "#95D866";
                        h.moveTo(x, y);
                    }
                    
                    // Continue country
                    h.lineTo(x, y);
                }
                
                h.closePath();
                h.fill();
                h.stroke();
            }
        }
        
        // Time out
        if(n == 2){
            if(o == 0){
                n = 3;
                o = 60;
                z = 1;
            }
        }
        
        // Puzzle feedback
        if(n == 3){
            
            // Draw target
            a = C[B][1];
            //_(C[B]);
            
            // Country / State
            if(A == 0 || A == 3 || A == 5 || A == 8 || A == 9){
                
                // Draw country/state in yellow
                h.fillStyle = "yellow";
                h.beginPath();

                // Loop on coordinates
                for(k = 0; k < a.length; k += 2){
                    
                    // Start new island
                    if(a[k] == 255){
                        k++;
                        h.closePath();
                        h.fill();
                        h.stroke();
                        if(o == 60){
                            if(h.isPointInPath(X, Y)){
                                p = 0;
                                c = [X, Y];
                            }
                        }
                        
                        h.beginPath();
                    }
                    
                    // hack
                    if(a[k + 1] == 255){
                        k += 2;
                        h.closePath();
                        h.fill();
                        h.stroke();
                        if(o == 60){
                            if(h.isPointInPath(X, Y)){
                                p = 0;
                                c = [X, Y];
                            }
                        }
                        h.beginPath();
                    }

                    // Current point
                    x = a[k] * (f == 4 ? 4.8 : 4.9);
                    y = a[k + 1] * (f == 4 ? 2.46 : 2.35) + (f == 4 ? 38 : 65);
                    if(B == 4 || B == 9){
                        x = 1200 - x;
                        y = 700 - y;
                    }
                    
                    // Test if it's the closest point to where we clicked
                    if(o == 60){
                        b = m.sqrt(m.pow(x - X, 2) + m.pow(y - Y, 2));
                        if(b < p){
                            p = b;
                            c = [x, y];
                        }
                    }
                    
                    // Start country
                    if(k == 0){
                        h.beginPath();
                        h.moveTo(x, y);
                    }
                    
                    // Continue country
                    h.lineTo(x, y);

                }
                
                h.closePath();
                h.fill();
                h.stroke();
                if(o == 60){
                    if(h.isPointInPath(X, Y)){
                        p = 0;
                        c = [X, Y];
                    }
                }
            }
            
            // Place / capitol
            else {
                x = a[0] * (f == 4 ? 4.8 : 4.9);
                y = a[1] * (f == 4 ? 2.46 : 2.35) + (f == 4 ? 38 : 65);
                if(B == 4 || B == 9){
                    x = 1200 - x;
                    y = 700 - y;
                }
                    
                h.fillStyle = "yellow";
                h.beginPath();
                h.arc(x, y, 10, 0, 7);
                h.fill();
                
                if(o == 60){
                    b = m.sqrt(m.pow(x - X, 2) + m.pow(y - Y, 2));
                    p = b;
                    c = [x, y];
                }
            }

            // If not timeout
            if(!z){
                
                // Drop flags, trace red line
                if(p > 5){
                    h.fillStyle = "green";
                    h.strokeStyle = "green";
                    h.beginPath();
                    h.moveTo(c[0], c[1]);
                    h.lineTo(c[0]-1, c[1]);
                    h.lineTo(c[0]-1, c[1]-40);
                    h.lineTo(c[0], c[1]-40);
                    h.lineTo(c[0]+20, c[1]-30);
                    h.lineTo(c[0], c[1]-20);
                    h.stroke();
                    h.fill();
                    
                    h.strokeStyle = "red";
                    h.lineWidth = "2";
                    h.setLineDash([5, 5]);
                    h.beginPath();
                    h.moveTo(X, Y);
                    h.lineTo(c[0], c[1]);
                    h.stroke();
                }
                
                h.setLineDash([0,0]);
                h.fillStyle = "blue";
                h.strokeStyle = "blue";
                h.beginPath();
                h.moveTo(X,Y);
                h.lineTo(X-1, Y);
                h.lineTo(X-1, Y-40);
                h.lineTo(X, Y-40);
                h.lineTo(X+20, Y-30);
                h.lineTo(X, Y-20);
                h.stroke();
                h.fill();
            }
            
            // Update score
            if(o == 45){
                if(A == 5 || A == 7 || A == 9 || A == 11){
                    e = (p < 100 ? (~~(p/10)) * 100 : (~~(p/100)) * 1000);
                    q -= z ? 5000 : e;
                }
                else{
                    e =  (p < 100 ? (~~(p/4)) * 100 : (~~(p/40)) * 1000);
                    q -= z ? 10000 : e;
                }
            }
            
            // Text
            if(o < 45){
                if(z){
                    t(600, 350, "TIME OUT", 100, B < 7 ? "#000" : "#fff");
                    if(A == 5 || A == 7 || A == 9 || A == 11){
                        t(600, 400, "5,000km penalty", 50, B < 7 ? "#000" : "#fff");
                    }
                    else {
                        t(600, 400, "10,000km penalty", 50, B < 7 ? "#000" : "#fff");
                    }
                }
                else{
                    t(600, 350, p > 5 ? e + "km away" : "PERFECT", 100, B < 7 ? "#000" : "#fff")
                }
            }
            
            
            d = 0;
            
            // Game over
            if(q <= 0){
                q = 0;
                d = 1;
            }
            
            // Go to black screen before next puzzle
            if(o == 0) {
                n = 4;
                o = 15;
            }
        }
        
        // UI
        h.beginPath();
        h.fillStyle = "#000";
        h.rect(0, 0, 1200, 66);
        h.fill();
        h.closePath();
        h.beginPath();
        h.fillStyle = "#fff";
        if(n == 2){
            h.rect(0, 60, o * 4, 5);
            h.fill();
        }
        h.closePath();
        
        t(10, 45,
        [
            "Country",
            "Capitol",
            "Place",
            "Country",
            "Capitol",
            "U.S. state",
            "Place",
            "U.S. capitol",
            "Country",
            "U.S. state",
            "Place",
            "U.S. capitol",
            "Capitol"
        ][A]
        
        + ": " + 
        
        C[B][0].toUpperCase(), 40, 0, "left");
        
        t(1190, 45, q + "km remaining", 40, 0, "right");
    }
    
    // Black screen between puzzles
    if(n == 4){
        
        // Game over
        if(d){
            n = 5;
        }
        
        // Prepare next screen
        h.fillRect(0,0,1200,650);
        if(o == 0){
            
            // Reset click
            X = 0;
            Y = 0;
            
            // Next puzzle
            B++;
            n = 2;
            p = 50000;
            o = 300;
            z = 0;
            
            // Or next level
            if(B > 9){
                B = 0;
                A++;
                n = 1;
                r += q;
                q = 30000;
                if(A == 5 || A == 7 || A == 9 || A == 11){
                    q = 20000;
                }
                
                // Or you won
                if(A > 12){
                    n = 5;
                }
            }
        }
    }
    
    // Game over
    if(n == 5){
        
        h.fillRect(0,0,1200,650);
        
        // Text
        t(600, 280, A == 13 ? "YOU WON!" : "GAME OVER!");
        
        t(600,  360, "Level " + (A + 1) + " ~ total score: " + r + "km", 40);
        
        t(600, 450, "TWEET YOUR SCORE / REPLAY", 30);
        
    }
    
    // Update frame counter
    if(o) o--;
    
    setTimeout(w, 33);
}


/** Handle Clicks **/
$.onclick = function(a){
    
    // Home screen => Level presentation screen
    if(n == 0){
        n = 1;
        
        // Shuffle data now
        b = function(){return .5 - m.random()}
        g[0][0].sort(b); // Places easy
        g[0][1].sort(b); // Places medium
        g[0][2].sort(b); // Places hard
        g[1][0].sort(b); // Capitols easy
        g[1][1].sort(b); // Capitols medium
        g[1][2].sort(b); // Capitols hard
        g[2][0].sort(b); // US capitols easy
        g[2][1].sort(b); // US capitols hard
        g[3][0].sort(b); // Countries easy
        g[3][1].sort(b); // Countries medium
        g[3][2].sort(b); // Countries hard
        g[4][0].sort(b); // US states easy
        g[4][1].sort(b); // US states hard
        //_(g);
    }
    
    // Level presentation screen => Puzzle screen
    else if(n == 1){
        n = 2;
        o = 300;
    }
    
    // Puzzle screen => Puzzle feedback
    else if(n == 2){
        X = a.pageX;
        Y = a.pageY;
        n = 3;
        o = 60;
    }
    
    // Puzzle screen => Puzzle feedback
    else if(n == 5){
        window.open("http://twitter.com/home?status=I played the @js13kgames game GeoQuiz by @MaximeEuziere. My score: " + (A + 1) + "levels, " + r + "km. Play here: http://xem.github.io/JS13k15");
        location = location;
    }
    
    // Other game states don't require clicking
}